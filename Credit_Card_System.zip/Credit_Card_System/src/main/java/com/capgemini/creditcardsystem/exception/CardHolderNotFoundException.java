package com.capgemini.creditcardsystem.exception;

public class CardHolderNotFoundException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

}
